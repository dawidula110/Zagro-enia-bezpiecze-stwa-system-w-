﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace WeatherChecker.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class WeatherForecastController : ControllerBase
    {
        [HttpGet]
        public IActionResult GetWeather()
        {
            var forecast = new
            {
                Temperature = "25°C",
                Condition = "Sunny"
            };

            return Ok(forecast);
        }
    }
}
