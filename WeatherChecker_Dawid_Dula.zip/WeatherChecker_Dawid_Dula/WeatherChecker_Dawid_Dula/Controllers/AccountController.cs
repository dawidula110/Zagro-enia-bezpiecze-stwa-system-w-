﻿using Microsoft.AspNetCore.Mvc;
using WeatherChecker.Models;
using WeatherChecker_Dawid_Dula.Interfaces;

namespace WeatherChecker.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly IJwtProviderService _jwtProviderService;
        private readonly IAccountService _accountService;

        public AccountController(IJwtProviderService jwtProviderService, IAccountService accountService)
        {
            _jwtProviderService = jwtProviderService;
            _accountService = accountService;
        }

        [HttpPost("register")]
        public IActionResult Register([FromBody] Account account)
        {
            if (_accountService.Register(account, account.PasswordHash))
                return Ok("User registered successfully");
            return BadRequest("User with this email already exists");
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] Account account)
        {
            var user = _accountService.Authenticate(account.Email, account.PasswordHash);
            if (user == null)
                return Unauthorized("Invalid credentials");

            var token = _jwtProviderService.GenerateToken(user);
            return Ok(new { Token = token });
        }
    }
}
