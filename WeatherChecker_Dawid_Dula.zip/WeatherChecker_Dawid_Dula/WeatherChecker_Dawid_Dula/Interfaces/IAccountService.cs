﻿using WeatherChecker.Models;

namespace WeatherChecker_Dawid_Dula.Interfaces
{
    public interface IAccountService
    {
        bool Register(Account account, string password);
        Account Authenticate(string email, string password);
    }
}
