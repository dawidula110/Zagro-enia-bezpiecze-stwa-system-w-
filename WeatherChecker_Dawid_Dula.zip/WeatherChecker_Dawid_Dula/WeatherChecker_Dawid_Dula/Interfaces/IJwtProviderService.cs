﻿using WeatherChecker.Models;

namespace WeatherChecker_Dawid_Dula.Interfaces
{
    public interface IJwtProviderService
    {
        string GenerateToken(Account account);
    }
}
