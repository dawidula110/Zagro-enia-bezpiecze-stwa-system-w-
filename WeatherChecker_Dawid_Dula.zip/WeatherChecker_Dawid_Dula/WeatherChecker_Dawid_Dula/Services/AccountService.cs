﻿using System.Security.Cryptography;
using System.Text;
using System.Linq;
using WeatherChecker.Models;
using WeatherChecker_Dawid_Dula.Interfaces;
using WeatherChecker_Dawid_Dula.Data;

namespace WeatherChecker_Dawid_Dula.Services
{
    public class AccountService : IAccountService
    {
        private readonly ApplicationDbContext _context;

        public AccountService(ApplicationDbContext context)
        {
            _context = context;
        }

        public bool Register(Account account, string password)
        {
            if (_context.Accounts.Any(a => a.Email == account.Email))
                return false;

            account.PasswordHash = HashPassword(password);
            _context.Accounts.Add(account);
            _context.SaveChanges();
            return true;
        }

        public Account Authenticate(string email, string password)
        {
            var account = _context.Accounts.FirstOrDefault(a => a.Email == email);
            if (account == null || !VerifyPassword(password, account.PasswordHash))
                return null;

            return account;
        }

        private string HashPassword(string password)
        {
            using var sha256 = SHA256.Create();
            var bytes = Encoding.UTF8.GetBytes(password);
            var hash = sha256.ComputeHash(bytes);
            return Convert.ToBase64String(hash);
        }

        private bool VerifyPassword(string password, string storedHash)
        {
            return HashPassword(password) == storedHash;
        }
    }
}
