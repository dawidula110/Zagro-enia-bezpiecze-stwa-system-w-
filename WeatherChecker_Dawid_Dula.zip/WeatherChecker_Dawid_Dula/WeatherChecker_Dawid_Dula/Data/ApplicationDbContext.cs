﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using WeatherChecker.Models;

namespace WeatherChecker_Dawid_Dula.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Account> Accounts { get; set; }
    }
}
