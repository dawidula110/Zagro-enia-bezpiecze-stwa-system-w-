﻿using Microsoft.AspNetCore.Http;
using System.Collections.Concurrent;

namespace WeatherChecker_BK.Middleware;

public class RateLimitingMiddleware
{
    private readonly RequestDelegate _next;
    private static readonly ConcurrentDictionary<string, List<DateTime>> _requests = new();
    private static readonly ConcurrentDictionary<string, DateTime> _blockedIps = new();

    public RateLimitingMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task Invoke(HttpContext context)
    {
        var ip = context.Connection.RemoteIpAddress?.ToString() ?? "unknown";
        var endpoint = context.Request.Path.ToString().ToLowerInvariant();
        var key = $"{ip}:{endpoint}";

        if (_blockedIps.TryGetValue(key, out var blockedUntil))
        {
            if (blockedUntil > DateTime.UtcNow)
            {
                context.Response.StatusCode = StatusCodes.Status429TooManyRequests;
                await context.Response.WriteAsync("Too many requests. Try again later.");
                return;
            }
            else
            {
                _blockedIps.TryRemove(key, out _);
            }
        }

        var now = DateTime.UtcNow;
        var requests = _requests.GetOrAdd(key, _ => new List<DateTime>());
        lock (requests)
        {
            requests.RemoveAll(dt => (now - dt).TotalSeconds > 30);
            requests.Add(now);

            if (requests.Count > 10)
            {
                _blockedIps[key] = now.AddSeconds(30);
                context.Response.StatusCode = StatusCodes.Status429TooManyRequests;
                context.Response.ContentType = "text/plain";
                context.Response.Headers["Retry-After"] = "30";
                context.Response.Headers["X-RateLimit-Reason"] = "Too many requests from this IP for this endpoint.";
                context.Response.Headers["X-RateLimit-Blocked-Until"] = _blockedIps[key].ToString("o");
                requests.Clear();
                context.Response.WriteAsync("Too many requests. This IP is blocked for 30 seconds.").Wait();
                return;
            }
        }
        await _next(context);
    }
}
