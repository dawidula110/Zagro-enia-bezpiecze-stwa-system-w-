﻿using Microsoft.AspNetCore.Http;
using System.Text;
using System.Threading.Tasks;

namespace WeatherChecker_BK.Middleware;

public class RequestLoggingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly string _logFilePath = "request_log.txt";

    public RequestLoggingMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task Invoke(HttpContext context)
    {
        var method = context.Request.Method;
        var time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        var ip = context.Connection.RemoteIpAddress?.ToString() ?? "unknown";

        string bodyContent = "";
        context.Request.EnableBuffering();
        if (context.Request.ContentLength > 0)
        {
            context.Request.Body.Position = 0;
            using (var reader = new StreamReader(context.Request.Body, Encoding.UTF8, leaveOpen: true))
            {
                bodyContent = await reader.ReadToEndAsync();
                context.Request.Body.Position = 0;
            }
        }

        string email = "";
        if (!string.IsNullOrEmpty(bodyContent) && bodyContent.Contains("email", StringComparison.OrdinalIgnoreCase))
        {
            var emailKey = "\"email\"";
            var idx = bodyContent.IndexOf(emailKey, StringComparison.OrdinalIgnoreCase);
            if (idx >= 0)
            {
                var after = bodyContent.Substring(idx + emailKey.Length);
                var start = after.IndexOf('"') + 1;
                var end = after.IndexOf('"', start);
                if (start > 0 && end > start)
                    email = after.Substring(start, end - start);
            }
        }

        var log = $"[{time}] {method} IP:{ip} Email:{email} Body:{bodyContent}{Environment.NewLine}";
        await File.AppendAllTextAsync(_logFilePath, log);

        await _next(context);
    }
}