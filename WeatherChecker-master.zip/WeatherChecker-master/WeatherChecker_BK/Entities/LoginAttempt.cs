﻿public class LoginAttempt
{
    public int Id { get; set; }
    public string IpAddress { get; set; }
    public string Email { get; set; }
    public DateTime AttemptTime { get; set; }
    public bool IsSuccess { get; set; }
    public bool IsBlocked { get; set; }
    public DateTime? BlockedUntil { get; set; }
}