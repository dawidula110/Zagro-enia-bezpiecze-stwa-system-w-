﻿namespace WeatherChecker_BK.Dtos;

public class RegisterAccountDto
{
    public string Email { get; set; }
    public string Password { get; set; }
    public string ConfirmPassword { get; set; }
    public string? TwoFactorCode { get; set; }
}
