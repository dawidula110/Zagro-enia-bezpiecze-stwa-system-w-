﻿namespace WeatherChecker_BK.Dtos;

public class LoginUserDto
{
    public string Email { get; set; }
    public string Passowrd { get; set; }
    public string? TwoFactorCode { get; set; }
}
