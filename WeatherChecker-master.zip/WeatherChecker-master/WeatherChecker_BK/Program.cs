using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using WeatherChecker_BK.Data;
using WeatherChecker_BK.Interfaces;
using WeatherChecker_BK.Middleware;
using WeatherChecker_BK.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<WeatherAppDbContext>(options => options.UseInMemoryDatabase("WeatherDbContext"));
builder.Services.AddScoped<IAccountService, AccountService>();
builder.Services.AddScoped<IJwtProviderService, JwtProviderService>();
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFrontend", policy =>
    {
        policy.WithOrigins("https://twojfrontend.pl")
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});
builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = "Bearer";
    options.DefaultScheme = "Bearer";
    options.DefaultChallengeScheme = "Bearer";
}).AddJwtBearer(cfg =>
{
    cfg.RequireHttpsMetadata = false;
    cfg.TokenValidationParameters = new TokenValidationParameters()
    {
        ValidIssuer = "weatcherchecker.com",
        ValidAudience = "weatcherchecker.com",
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("18cebc1b-13aa-479e-b8a4-3c5e227be53c")),
    };
});

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseMiddleware<SecurityMiddleware>();

app.UseHttpsRedirection();

app.UseMiddleware<WeatherChecker_BK.Middleware.RequestLoggingMiddleware>();

app.UseMiddleware<WeatherChecker_BK.Middleware.RateLimitingMiddleware>();

app.UseAuthorization();

app.MapControllers();

app.UseCors("AllowFrontend");

app.Run();
    