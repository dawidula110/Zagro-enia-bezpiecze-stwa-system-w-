﻿using WeatherChecker_BK.Dtos;
using WeatherChecker_BK.Models;

namespace WeatherChecker_BK.Interfaces;

public interface IJwtProviderService
{
    string GenerateJwtToken(LoginUserDto loginUserDto);
}