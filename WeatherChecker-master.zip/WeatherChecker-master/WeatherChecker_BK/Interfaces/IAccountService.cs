﻿using WeatherChecker_BK.Dtos;
using WeatherChecker_BK.Entities;
using Microsoft.AspNetCore.Identity;

namespace WeatherChecker_BK.Interfaces;

public interface IAccountService
{
    List<Account> GetAccounts();
    Account CreateAccount(RegisterAccountDto accountDto);
    bool LoginUser(LoginUserDto loginUserDto);
    string GenerateTwoFactorCode(string email);
    bool ValidateTwoFactorCode(string email, string code);
    bool RegisterUser(RegisterAccountDto registerAccountDto);
}
