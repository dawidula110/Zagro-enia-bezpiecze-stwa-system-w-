﻿using Microsoft.EntityFrameworkCore;
using WeatherChecker_BK.Entities;

namespace WeatherChecker_BK.Data
{
    public class WeatherAppDbContext : DbContext
    {
        public WeatherAppDbContext(DbContextOptions<WeatherAppDbContext> options) : base(options) { }

        public DbSet<Account> Accounts { get; set; }
        public DbSet<LoginAttempt> LoginAttempts { get; set; }
    }
}
