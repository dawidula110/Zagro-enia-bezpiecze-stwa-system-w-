﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using WeatherChecker_BK.Dtos;
using WeatherChecker_BK.Entities;
using WeatherChecker_BK.Interfaces;
using WeatherChecker_BK.Models;

namespace WeatherChecker_BK.Controllers;

[Route("api/[controller]")]
[ApiController]
public class AccountController : ControllerBase
{
    private readonly IAccountService _accountService;
    private readonly IJwtProviderService _jwtProviderService;

    public AccountController(IJwtProviderService jwtProviderService, IAccountService accountService)
    {
        _accountService = accountService;
        _jwtProviderService = jwtProviderService;
    }

    [HttpPost("login")]
    public async Task<ActionResult<string>> LoginUser([FromBody] LoginUserDto loginUserDto, CancellationToken cancellationToken)
    {
        try
        {
            var userCanBeLogin = _accountService.LoginUser(loginUserDto);
            if (!userCanBeLogin)
                return BadRequest("User can not be login");

            if (string.IsNullOrEmpty(loginUserDto.TwoFactorCode))
            {
                var code = _accountService.GenerateTwoFactorCode(loginUserDto.Email);
                return Ok(new { TwoFactorCode = code });
            }

            if (!_accountService.ValidateTwoFactorCode(loginUserDto.Email, loginUserDto.TwoFactorCode))
                return BadRequest("Invalid two factor code");

            var result = _jwtProviderService.GenerateJwtToken(loginUserDto);
            return Ok(result);
        }
        catch (Exception ex)
        {
            return BadRequest(ex.Message);
        }
    }

    [HttpPost("register")]
    public async Task<ActionResult<bool>> RegisterUser([FromBody] RegisterAccountDto registerAccountDto, CancellationToken cancellationToken)
    {
        try
        {
            var result = _accountService.RegisterUser(registerAccountDto);
            return Ok(result);
        }
        catch (Exception ex)
        {
            if (ex.Message.StartsWith("TwoFactorCode:"))
            {
                var code = ex.Message.Replace("TwoFactorCode:", "");
                return Ok(new { TwoFactorCode = code });
            }
            return BadRequest(ex.Message);
        }
    }

    [HttpPost("create")]
    public async Task<ActionResult<Account>> CreateUser([FromBody] RegisterAccountDto accountDto, CancellationToken cancellationToken)
    {
        var result = _accountService.CreateAccount(accountDto);
        return Ok(result);
    }

    [HttpGet("all")]
    [Authorize(Roles = "Admin")]
    public ActionResult<List<Account>> GetAccounts()
    {
        var result = _accountService.GetAccounts();
        return Ok(result);
    }
}
