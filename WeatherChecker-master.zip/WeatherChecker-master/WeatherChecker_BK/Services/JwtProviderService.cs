﻿using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using WeatherChecker_BK.Data;
using WeatherChecker_BK.Dtos;
using WeatherChecker_BK.Interfaces;
using WeatherChecker_BK.Models;

namespace WeatherChecker_BK.Services;

public class JwtProviderService : IJwtProviderService
{
    private readonly WeatherAppDbContext _dbContext;

    public JwtProviderService(WeatherAppDbContext dbContext)
    {
        _dbContext = dbContext;
    }
    public string GenerateJwtToken(LoginUserDto loginUserDto)
    {
        var user = _dbContext.Accounts.FirstOrDefault(x => x.Email == loginUserDto.Email);

        var claims = new List<Claim>()
        {
            new Claim(ClaimTypes.Email, loginUserDto.Email),
            new Claim("Activated", true.ToString()),
            new Claim(ClaimTypes.Role, user?.Role ?? "User")
        };

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("18cebc1b-13aa-479e-b8a4-3c5e227be53c"));
        var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
        var expires = DateTime.Now.AddDays(1);

        var token = new JwtSecurityToken("weatcherchecker.com", "weatcherchecker.com", claims, expires: expires, signingCredentials: credentials);
        var tokenHandler = new JwtSecurityTokenHandler();

        return tokenHandler.WriteToken(token);
    }
}
