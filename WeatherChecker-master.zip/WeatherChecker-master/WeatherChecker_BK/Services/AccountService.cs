﻿using WeatherChecker_BK.Data;
using WeatherChecker_BK.Dtos;
using WeatherChecker_BK.Entities;
using WeatherChecker_BK.Interfaces;
using System.Linq;

namespace WeatherChecker_BK.Services;

public class AccountService : IAccountService
{
    private readonly WeatherAppDbContext _weatherAppDbContext;

    public AccountService(WeatherAppDbContext weatherAppDbContext) 
    {
        _weatherAppDbContext = weatherAppDbContext;
    }

    public Account CreateAccount(RegisterAccountDto accountDto)
    {
        var account = new Account()
        {
            Email = accountDto.Email,
            Password = accountDto.Password,
        };
        var result = _weatherAppDbContext.Accounts.Add(account);
        _weatherAppDbContext.SaveChanges();

        return result.Entity;
    }

    public List<Account> GetAccounts()
    {
        return _weatherAppDbContext.Accounts.ToList();
    }
    public bool LoginUser(LoginUserDto loginUserDto, string ipAddress)
    {
        DetectSqlInjection(loginUserDto.Email, loginUserDto.Passowrd);
        var now = DateTime.Now;

        var recentAttempts = _weatherAppDbContext.LoginAttempts
            .Where(a => a.IpAddress == ipAddress && a.AttemptTime > now.AddDays(-1))
            .ToList();

        var blockedAttempt = recentAttempts
            .FirstOrDefault(a => a.IsBlocked && a.BlockedUntil.HasValue && a.BlockedUntil > now);

        if (blockedAttempt != null)
            throw new Exception($"This IP is blocked until {blockedAttempt.BlockedUntil.Value}.");

        var failedAttempts = recentAttempts.Count(a => !a.IsSuccess);

        if (failedAttempts >= 100)
        {
            var block = new LoginAttempt
            {
                IpAddress = ipAddress,
                Email = loginUserDto.Email,
                AttemptTime = now,
                IsSuccess = false,
                IsBlocked = true,
                BlockedUntil = now.AddHours(1)
            };
            _weatherAppDbContext.LoginAttempts.Add(block);

            var user = _weatherAppDbContext.Accounts.FirstOrDefault(x => x.Email == loginUserDto.Email);
            if (user != null)
            {
                user.LockoutEnd = now.AddHours(1);
            }

            _weatherAppDbContext.SaveChanges();
            throw new Exception($"Too many failed attempts. This IP is blocked for 1 hour.");
        }

        var userAccount = _weatherAppDbContext.Accounts.FirstOrDefault(x => x.Email == loginUserDto.Email);
        bool isSuccess = userAccount != null && userAccount.Password == loginUserDto.Passowrd;

        _weatherAppDbContext.LoginAttempts.Add(new LoginAttempt
        {
            IpAddress = ipAddress,
            Email = loginUserDto.Email,
            AttemptTime = now,
            IsSuccess = isSuccess,
            IsBlocked = false
        });

        _weatherAppDbContext.SaveChanges();

        if (userAccount == null)
            throw new Exception($"Account with this email {loginUserDto.Email} not exist!");

        if (userAccount.LockoutEnd.HasValue && userAccount.LockoutEnd > now)
            throw new Exception($"Account is locked. Try again at {userAccount.LockoutEnd.Value}.");

        if (!isSuccess)
        {
            userAccount.FailedLoginAttempts++;
            if (userAccount.FailedLoginAttempts >= 5)
            {
                userAccount.LockoutEnd = now.AddMinutes(10);
                userAccount.FailedLoginAttempts = 0;
            }
            _weatherAppDbContext.SaveChanges();
            throw new Exception($"Password for user {loginUserDto.Email} is incorrect!");
        }

        userAccount.FailedLoginAttempts = 0;
        userAccount.LockoutEnd = null;
        _weatherAppDbContext.SaveChanges();

        return true;
    }
    public bool RegisterUser(RegisterAccountDto accountDto)
    {
        DetectSqlInjection(accountDto.Email, accountDto.Password, accountDto.ConfirmPassword);
        if (accountDto.Password != accountDto.ConfirmPassword)
            throw new Exception($"Password and confirm Password are not the same!");

        var userAccount = _weatherAppDbContext.Accounts.FirstOrDefault(x => x.Email == accountDto.Email);
        if (userAccount is not null)
            throw new Exception($"Account with email {accountDto.Email} already exist!");

        if (string.IsNullOrEmpty(accountDto.TwoFactorCode))
        {
            var code = GenerateTwoFactorCode(accountDto.Email);
            throw new Exception($"TwoFactorCode:{code}");
        }

        if (!ValidateTwoFactorCode(accountDto.Email, accountDto.TwoFactorCode))
            throw new Exception("Invalid two factor code");

        var passwordHasher = new Microsoft.AspNetCore.Identity.PasswordHasher<Account>();
        var account = new Account()
        {
            Email = accountDto.Email,
            Role = "User"
        };
        account.Password = passwordHasher.HashPassword(account, accountDto.Password);

        var result = _weatherAppDbContext.Accounts.Add(account);
        _weatherAppDbContext.SaveChanges();

        return result.Entity.Id > 0;
    }

    private static readonly Dictionary<string, string> _twoFactorCodes = new();

    public string GenerateTwoFactorCode(string email)
    {
        var code = new Random().Next(100000, 999999).ToString();
        _twoFactorCodes[email] = code;
        return code;
    }

    public bool ValidateTwoFactorCode(string email, string code)
    {
        return _twoFactorCodes.TryGetValue(email, out var storedCode) && storedCode == code;
    }

    public bool LoginUser(LoginUserDto loginUserDto)
    {
        throw new NotImplementedException();
    }

    private static readonly string[] SqlInjectionPatterns = new[]
{
    "--", ";--", ";", "/*", "*/", "@@",
    "char", "nchar", "varchar", "nvarchar",
    "alter", "begin", "cast", "create", "cursor", "declare", "delete",
    "drop", "end", "exec", "execute", "fetch", "insert", "kill",
    "open", "select", "sys", "sysobjects", "syscolumns", "table", "update",
    "'", "\"", " or ", " and ", "1=1", "1=0"
};
    private void DetectSqlInjection(params string[] inputs)
    {
        foreach (var input in inputs)
        {
            if (string.IsNullOrEmpty(input)) continue;
            var lowered = input.ToLowerInvariant();
            foreach (var pattern in SqlInjectionPatterns)
            {
                if (lowered.Contains(pattern))
                {
                    throw new Exception("Request rejected: possible SQL Injection detected.");
                }
            }
        }
    }
}